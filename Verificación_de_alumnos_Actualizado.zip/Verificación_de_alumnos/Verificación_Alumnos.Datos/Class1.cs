﻿using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Linq;
namespace Verificación_Alumnos.Datos
{
    public class AlumnoDatos
    {
        private string _conexionString =
     "Server=127.0.0.1;Port=3307;Database=archivo;Uid=root;Pwd=;";

        public (string Legajo, string Nombre, int Condicion)? BuscarPorLegajo(string legajo)
        {
            string query = "SELECT Legajo, Nombre, Condicion FROM alumno WHERE Legajo = @Legajo";
            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Legajo", legajo);
                conexion.Open();
                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        string legajoDb = reader["Legajo"].ToString();
                        string nombreDb = reader["Nombre"].ToString();
                        int condicionDb = reader.GetInt32("Condicion");

                        return (legajoDb, nombreDb, condicionDb);
                    }
                }
            }
            return null;
        }
    }
}

