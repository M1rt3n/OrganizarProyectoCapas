﻿using System;
using SolucionCapas.Datos;

namespace SolucionCapas.Negocio
{
    
    public class Producto
    {
        public int Codigo { get; set; }
        public string Nombre { get; set; }
        public int Precio { get; set; }
    }

    public class ProductoNegocio
    {
        private ProductoDatos _datos = new ProductoDatos();

        public Producto ObtenerProducto(int codigo)
        {
            var resultado = _datos.BuscarPorCódigo(codigo);

            if (resultado == null) return null;

            return new Producto
            {
                Codigo = resultado.Value.Codigo,
                Nombre = resultado.Value.Nombre,
                Precio = resultado.Value.Precio
            };
        }
    }
}