﻿using System;
using SolucionCapas.Negocio;

public class Program
{
    public static void Main()
    {
        Console.Write("Ingrese Código: ");
        int codigo = Convert.ToInt32(Console.ReadLine());

        ProductoNegocio negocio = new ProductoNegocio();

        Producto producto = negocio.ObtenerProducto(codigo);

        if (producto != null)
            Console.WriteLine($"Encontrado: {producto.Nombre} , Precio: ${producto.Precio}");
        else
            Console.WriteLine("No existe.");
    }
}
