﻿using MySql.Data.MySqlClient;
namespace SolucionCapas.Datos
{
    public class ProductoDatos
    {
        private string _conexionString =
        "Server=127.0.0.1;Port=3307;Database=almacen;Uid=root;Pwd=;";


        public (int Codigo, string Nombre, int Precio)? BuscarPorCódigo(int codigo)
        {
            string query = "SELECT Codigo, Nombre, Precio FROM producto WHERE Codigo = @Codigo";
            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Codigo", codigo);
                conexion.Open();
                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int codigoDb = reader.GetInt32("Codigo");
                        string nombreDb = reader["Nombre"].ToString();
                        int precioDb = reader.GetInt32("Precio");
                        return (codigoDb, nombreDb, precioDb);
                    }
                }
            }
            return null;
        }
    }
}