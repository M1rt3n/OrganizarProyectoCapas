﻿using MySql.Data.MySqlClient;
namespace Busqueda_Libros.Datos
{
    public class LibrosDatos
    {
        private string _conexionString =
        "Server=127.0.0.1;Port=3307;Database=biblioteca;Uid=root;Pwd=;";


        public (long ISBN, string Titulo, string Autor, bool Disponible)? BuscarPorISBN(long isbn)
        {
            string query = "SELECT ISBN, Titulo, Autor, Disponible FROM libro WHERE ISBN = @ISBN";
            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@ISBN", isbn);
                conexion.Open();
                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        long isbnDb = reader.GetInt64("ISBN");
                        string tituloDb = reader["Titulo"].ToString();
                        string autorDb = reader["Autor"].ToString();
                        bool disponibleDb = reader.GetBoolean("Disponible");

                        return (isbnDb, tituloDb, autorDb, disponibleDb);
                    }
                }
            }
            return null;
        }
    }
}