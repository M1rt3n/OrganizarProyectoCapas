﻿using MySql.Data.MySqlClient;
using System.Net;
using System.Reflection.Metadata.Ecma335;
namespace Consulta_Empleados.Datos
{
    public class EmpleadosDatos
    {
        private string _conexionString =
     "Server=127.0.0.1;Port=3306;Database=empresa;Uid=root;Pwd=;";


        public (int Id, string Nombre, string Puesto, string Departamento)? BuscarPorId(int id)
        {
            string query = "SELECT Id, Nombre, Puesto, Departamento FROM empleado WHERE Id = @Id";
            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Id", id);
                conexion.Open();
                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int idDb = reader.GetInt32("Id");
                        string nombreDb = reader["Nombre"].ToString();
                        string puestoDb = reader["Puesto"].ToString();
                        string departamentoDb = reader["Departamento"].ToString();

                        return (idDb, nombreDb, puestoDb, departamentoDb);
                    }
                }
            }
            return null;
        }
    }
}
